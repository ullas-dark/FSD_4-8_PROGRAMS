# FSD Lab Server Files: Programs 4–8

This archive contains program-wise `app.js` files and optional `server.js` entry points.

## Important source clarification
The uploaded lab manuals describe an Express Generator project. They use `bin/www` as the actual server entry point (`npm start`, or for Program 8 `node ./bin/www`). They do not provide a separate file named `server.js`.

Therefore:
- `app.js` follows the program-specific configuration described in the manuals.
- `server.js` is added as an optional standalone launcher. Run it with `node server.js` only if you choose to use this launcher.
- For the original lab setup, keep the starter project's `bin/www` and run `npm start`.

## Dependencies / supporting files
These files are not complete projects by themselves. Copy each program's files into its corresponding Express project and retain that project's `package.json`, `bin/www`, `routes`, `models`, `views`, and `public` folders.

Program-specific database settings:
- Program 4: no MongoDB connection in this experiment.
- Program 5: no database; uses `express-validator` in `routes/users.js`.
- Program 6: `mongodb://127.0.0.1:27017/studentDB`
- Program 7: `mongodb://127.0.0.1:27017/studentDB`
- Program 8: `mongodb://127.0.0.1:27017/authDB`

The standard Express Generator template below uses the `jade` view engine as shown in the original starter template. If your starter project's `app.js` uses a different view engine, preserve that existing setting and its matching view files.
